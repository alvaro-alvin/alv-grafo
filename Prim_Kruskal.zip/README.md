## alv-grafo
# Implementation of a graph
This is a college work and (for now) should not be used in any real application!

## Building
To build the program using Make execute in the project folder:

    $ make setup
    $ make

The executable test file will be located in the `bin` folder
