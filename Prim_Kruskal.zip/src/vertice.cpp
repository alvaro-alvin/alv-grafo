#include "../headers/Vertice.hpp"

Vertice::Vertice(unsigned int id){
    Vertice::id = id;
}